document.addEventListener("DOMContentLoaded", () => {
    // 1. Mostrar o que tem cache local
    chrome.storage.local.get(["nordyToken", "sintetixUrl", "targetId"], (res) => {
        if (res.nordyToken) {
            updateUI(res.nordyToken);
        }
        if (res.sintetixUrl) document.getElementById("sintetix-url").value = res.sintetixUrl;
        if (res.targetId) document.getElementById("target-id").value = res.targetId;
    });

    // 2. Extração ATIVA (varredura imediata ao abrir o popup)
    chrome.cookies.getAll({ domain: "nordy.ai" }, (cookies) => {
        console.log("Cookies encontrados:", cookies);

        let atkToken = null;
        let veilToken = null;
        let allCookieNames = [];

        for (let c of cookies) {
            allCookieNames.push(c.name);
            if (c.name === "ATK") atkToken = c.value;
            if (c.name === "ch-veil-id") veilToken = c.value;
        }

        let foundToken = (atkToken && veilToken) ? `ch-veil-id=${veilToken}; ATK=${atkToken}` : null;

        if (foundToken) {
            chrome.storage.local.set({ nordyToken: foundToken });
            updateUI(foundToken);
        } else {
            // Debug Mode: se não achamos os padrões, imprimimos na tela pro usuário ver os nomes!
            if (cookies.length > 0) {
                document.getElementById("no-token-view").innerHTML = `
                    <p style="font-size: 13px; color: #ff9800;">Não encontramos o cookie ATK. Mas achamos esses:</p>
                    <div style="font-family: monospace; font-size:10px; color:#aaa; margin-top:8px;">${allCookieNames.join("<br/>")}</div>
                `;
            } else {
                document.getElementById("no-token-view").innerHTML = `
                    <p style="font-size: 13px; color: #ef4444;">Nenhum cookie da nordy.ai encontrado! Tente recarregar a tela da Nordy.</p>
                `;
            }
        }
    });

    // Tentar pegar do dominio .nordy.ai (com ponto inicial) para cookies root abrangentes
    chrome.cookies.getAll({ domain: ".nordy.ai" }, (cookies) => {
        let atkToken = null;
        let veilToken = null;
        for (let c of cookies) {
            if (c.name === "ATK") atkToken = c.value;
            if (c.name === "ch-veil-id") veilToken = c.value;
        }
        let foundToken = (atkToken && veilToken) ? `ch-veil-id=${veilToken}; ATK=${atkToken}` : null;

        if (foundToken) {
            chrome.storage.local.set({ nordyToken: foundToken });
            updateUI(foundToken);
        }
    });
});

function updateUI(token) {
    document.getElementById("no-token-view")?.classList.add("hidden");
    document.getElementById("has-token-view")?.classList.remove("hidden");

    const tokenDisplay = document.getElementById("token-val");
    if (tokenDisplay) {
        tokenDisplay.innerText = token.substring(0, 15) + "..." + token.substring(token.length - 10);
    }

    const btnCopy = document.getElementById("btn-copy");
    if (btnCopy) {
        // Remover listeners antigos clonando o botao
        const newBtn = btnCopy.cloneNode(true);
        btnCopy.parentNode.replaceChild(newBtn, btnCopy);

        newBtn.addEventListener("click", () => {
            navigator.clipboard.writeText(token).then(() => {
                newBtn.innerText = "Copiado!";
                newBtn.style.background = "#22c55e";
                setTimeout(() => {
                    newBtn.innerText = "Copiar Manualmente";
                    newBtn.style.background = "#8b5cf6";
                }, 2000);
            });
        });
    }

    const btnSync = document.getElementById("btn-sync");
    const syncMsg = document.getElementById("sync-msg");
    const urlInput = document.getElementById("sintetix-url");
    const targetInput = document.getElementById("target-id");

    if (btnSync && urlInput && targetInput && syncMsg) {
        // Remover listener clonando
        const newSync = btnSync.cloneNode(true);
        btnSync.parentNode.replaceChild(newSync, btnSync);

        newSync.addEventListener("click", async () => {
            let url = urlInput.value.trim();
            let targetId = targetInput.value.trim();

            if (!url) {
                syncMsg.innerText = "Preencha a URL de destino primeiro.";
                syncMsg.style.color = "#ef4444";
                return;
            }

            // Fallback elegante silenciado para Admin:
            if (url.endsWith("/admin")) {
                url = url.slice(0, -6);
                targetId = "admin";
            }
            if (!targetId) targetId = "admin";

            // Salva as configs pro cara nao digitar de novo sempre
            chrome.storage.local.set({ sintetixUrl: urlInput.value.trim(), targetId: targetInput.value.trim() });

            newSync.innerText = "Enviando...";
            syncMsg.innerText = "";

            try {
                const endpoint = url + (url.endsWith("/") ? "api/nordy/auth" : "/api/nordy/auth");
                const res = await fetch(endpoint, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ cookieString: token, targetId: targetId })
                });

                if (res.ok) {
                    newSync.innerText = "Enviado com Sucesso!";
                    newSync.style.background = "#22c55e";
                    syncMsg.innerText = "Plataforma Sintetix atualizada!";
                    syncMsg.style.color = "#22c55e";
                } else {
                    const data = await res.json().catch(() => ({}));
                    syncMsg.innerText = "Erro: " + (data.error || res.statusText);
                    syncMsg.style.color = "#ef4444";
                    newSync.innerText = "Tentar Novamente";
                    newSync.style.background = "#ef4444";
                }
            } catch (e) {
                syncMsg.innerText = "Falha de Conexão. Verifique a URL.";
                syncMsg.style.color = "#ef4444";
                newSync.innerText = "Tentar Novamente";
                newSync.style.background = "#ef4444";
            }

            setTimeout(() => {
                if (newSync.innerText !== "Enviado com Sucesso!") {
                    newSync.innerText = "Enviar Automático";
                    newSync.style.background = "#2563eb";
                }
            }, 3000);
        });
    }
}
