// Quando a extensão instala ou o Chrome inicia
chrome.runtime.onInstalled.addListener(() => {
    console.log("Sintetix Nordy Link instalado com sucesso.");
});

// Listener que capta qualquer mudança nos cookies ativamente
chrome.cookies.onChanged.addListener((changeInfo) => {
    const cookie = changeInfo.cookie;

    // Confere se é da Nordy e o nome provável do auth token deles 
    // (Pela minha análise prévia, costuma ser "__Secure-authjs.session-token" ou o de sessão normal)
    if (cookie.domain.includes("nordy.ai") && changeInfo.cause !== "evicted") {

        if (cookie.name === "ATK") {
            const capturedToken = cookie.value;
            console.log("Token do Nordy Capturado!", capturedToken.substring(0, 10) + "...");

            // Salva no storage interno da extensão para o popup.html poder ler
            chrome.storage.local.set({ nordyToken: capturedToken }, () => {
                console.log("Token armazenado no storage da extensão.");
            });

            // AQUI DEPOIS PODEMOS ADICIONAR UM FETCH PRA ENVIAR PRA SUA API:
            // fetch("https://sintetix.sua-api.com/api/update-token", {
            //   method: "POST",
            //   headers: { "Content-Type": "application/json" },
            //   body: JSON.stringify({ token: capturedToken })
            // })
        }
    }
});
